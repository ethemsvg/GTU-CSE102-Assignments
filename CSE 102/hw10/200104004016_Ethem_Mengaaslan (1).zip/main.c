#include <stdio.h>
#include <stdlib.h>

#define STACK_BLOCK_SIZE 10

typedef struct stack
{
    int *array;
    int maxsize;
    int currentsize;

}stack;

stack* init_return();
int init(stack *s);
int push(stack *s, int disk);
int pop(stack *s);
void towersOfHanoi(int numOfDisks, stack *from, stack *aux, stack *to);
void moveDisks(stack *from, stack *to, char f, char t);
void rearrange_size_of_stack(stack *s,int numOfDisks);

int main(){

    int i;
    int numOfDisks;

    // Creating stacks for each pole of the game
    stack *from = init_return();
	if(init(from) == 0){
        printf("An error has occured while creating stack FROM.");
        return -111;
	}
	stack *to = init_return();
	if(init(to) == 0){
        printf("An error has occured while creating stack TO.");
        return -111;
	}
	stack *aux = init_return();
	if(init(aux) == 0){
        printf("An error has occured while creating stack AUXILLARY.");
        return -111;
	}

    do{
        printf("Please enter the number of disks: ");
        scanf("%d",&numOfDisks);
        if(numOfDisks<1 ){
            printf("Please enter a valid value.\n");
        }
    }while(numOfDisks < 1 );

    rearrange_size_of_stack(to,numOfDisks);
    rearrange_size_of_stack(from,numOfDisks);
    rearrange_size_of_stack(aux,numOfDisks);
    

    // This for block adds/removes disks and at the same time expands or shrinks the size of pole arrays,
   // until they become the size that the user has entered.

   // THE LOOP BELOW SHRINK OR EXPAND THE SIZES OF STACK'S ARRAYS ONE BY ONE !!

    

	towersOfHanoi(numOfDisks, from, aux, to);
	return 0;
}

void rearrange_size_of_stack(stack *s,int numOfDisks){
	if(s->maxsize != numOfDisks){
		// Stacks firstly get created as they have 10 disks, but after the user input, 
	       // the size must shrink or expand to the size which the user has entered.
	 
		s->maxsize=numOfDisks;
		s->array=(int *)malloc((numOfDisks+1)*sizeof(int));

	}
}

// Creates and returns stacks for the poles.

// With the size of STACK_BLOCK_SIZE.
stack* init_return(){

    stack *s = (stack*)malloc(sizeof(stack));

    s->array = (int*) malloc(STACK_BLOCK_SIZE*sizeof(int));
    s->maxsize = STACK_BLOCK_SIZE;
    s->currentsize = -1; // When we add an item to the stack, we first increment the currentsize value by 1 so the first index of the array becomes zero. Thats why this value is -1.

    return s;
}

// Checks whether the desired stack had created without any errors.
int init(stack *s){
    if(s->currentsize == -1){
        return 1;
    }else return 0;
}

int push(stack *s, int disk){ // Function for basic push operation for stacks.

    int newCapacityExpand;

    if(s->currentsize == s->maxsize - 1){
        return 0;
    }else{
        s->currentsize++;
        newCapacityExpand = s->currentsize;  // Expanding the size of the stack.
        s->array[newCapacityExpand] = disk; // And pushing the desired disk.
        return 1;
    }
}

int pop(stack *s){ // Function for basic pop operation for stacks.

    int popped;

    if (s->currentsize == -1){
        return -999;
    }else{
        popped = s->array[s->currentsize];      // Store the popped value before discarding it within the array.
        s->currentsize--;       // Also shrinking the size of the stack as we have discarded one element.
        return popped;
    }
}


void towersOfHanoi(int numOfDisks, stack *from, stack *aux, stack *to){

	int i;

	// The bigger disks will be pushed before others.
	for (i = numOfDisks; i >= 1; i--){
		push(from, i);
	}

	char f = '1'; // The FROM pole.
	char t = '3'; // The TO pole.
	char a = '2'; // The AUXILLARY pole.
	int temp; // For swapping the poles below.

	// The logic of moves slightly changes according to the number of disks being even or odd. If they are even, the TO pole and AUXILLARY pole must be SWAPPED.
	if (numOfDisks % 2 == 0){
        	temp = a;
		a = t;
		t = temp;
	}

    int totalMoves;

	totalMoves = 1; // This value will be iterated below and give the total number of moves in order to complete the game.

	for(i=0;i<numOfDisks;i++){
        totalMoves*=2;
	}

	totalMoves--;

    // THE MOVES:
	for (i = 1; i <= totalMoves; i++){

        if (i % 3 == 0){   // If the move number is a multiple of 3, the move is to move the top disk from AUXILLARY pole to TO pole.
            moveDisks(aux, to, a, t);
        }else if (i % 3 == 1){ // If the mod of the move number is 1, the move is to move the top disk from FROM pole to TO pole.
            moveDisks(from, to, f, t);
		}else if (i % 3 == 2){ // If the mod of the move number is 2, the move is to move the top disk from FROM pole to AUXILLARY pole.
            		moveDisks(from, aux, f, a);
		}

	}
}

// Moves the disks accordingly to the availability of the poles, between 2 given input poles which are given by the main towersOfHanoi function and change dependant to the situation.
void moveDisks(stack *from, stack *to, char f, char t){

	int Pole1Top;
    Pole1Top = pop(from);

	int Pole2Top;
	Pole2Top = pop(to);

	if (Pole1Top == -999){ // If pole 1 is empty.

		push(from, Pole2Top);
		printf("Moving disk %d from pole '%c' to pole '%c'.\n",Pole2Top,t,f);

	}else if (Pole2Top == -999){ // If pole 2 is empty.

		push(to, Pole1Top);
        printf("Moving disk %d from pole '%c' to pole '%c'.\n",Pole1Top,f,t);

	}else if (Pole1Top < Pole2Top){	// If the disk on Pole 1 is smaller than the disk on Pole 2

	    	push(to, Pole2Top);
		push(to, Pole1Top);
		printf("Moving disk %d from pole '%c' to pole '%c'.\n",Pole1Top,f,t);

	}else if(Pole2Top < Pole1Top){ // If the disk on Pole 2 is smaller than the disk on Pole 1

		push(from, Pole1Top);
		push(from, Pole2Top);
		printf("Moving disk %d from pole '%c' to pole '%c'.\n",Pole2Top,t,f);
	}else{
        printf("Error occured during the algorithm. Contact to the developer.");
	}
}



