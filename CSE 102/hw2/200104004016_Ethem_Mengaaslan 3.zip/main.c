#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {

    int operationCode = 0;

    //Variables for example part
    int t;
    double p;
    double h;
    int s;
    int w;

    //Variables for part1
    float PL=0;
    float PW=0;

    //Variables for part2
    float x1=0;
    float x2=0;
    float x3=0;
    float x4=0;
    float x5=0;

    //Variables for part3;
    float BMI=0;
    float shoeSize=0;
    int sex;
    int boneType=0;
    int activityLvl=0;

    printf("Please enter temperature, pressure, humidity, sunny day or not(1 for yes, 0 for no) and day of the week(from 1 to 7):\n");
    scanf("%d",&t);
    scanf("%lf",&p);
    scanf("%lf",&h);
    scanf("%lf",&s);
    scanf("%lf",&w);

    if(dt0(t,p,h,s,w)==0){
        printf("AC is turned off\n");
    }else{
        printf("AC is turned on\n\n");
    }



    printf("Please enter the operation you want to perform:\n"); // User picks an option from 3 different operations.
    printf("(1) PART 1 / OPERATION 1\n");
    printf("(2) PART 2 / OPERATION 2\n");
    printf("(3) PART 3 / OPERATION 3\n");
    scanf("%d",&operationCode);



    switch(operationCode){

    case 1:
        printf("Please enter the PL and PW values sequentially.");
        printf("PL:");
        scanf("%f",&PL);
        printf("PW:");
        scanf("%f",&PW);

        if(dt1a(PL,PW) == dt1b(PL,PW)){ // Checks if decision trees had came to the same result or not.
            printf("Decision trees had came to the same result:  \n");

            // Prints the answers corresponding to the char values returned by the functions.
            if(dt1a(PL,PW) == 'x') printf("Setosa");
            else if(dt1a(PL,PW) == 'y') printf("Virginica");
            else if(dt1a(PL,PW) == 'z') printf("Versicolor");

        }else{
            printf("Decision trees had came to different results:\n");

            printf("The result of the first decision tree:\n");

            if(dt1a(PL,PW) == 'x') printf("Setosa\n");
            else if(dt1a(PL,PW) == 'y') printf("Virginica\n");
            else if(dt1a(PL,PW) == 'z') printf("Versicolor\n");

            printf("The result of the second decision tree:\n");
            if(dt1b(PL,PW) == 'x') printf("Setosa\n");
            else if(dt1b(PL,PW) == 'y') printf("Virginica\n");
            else if(dt1b(PL,PW) == 'z') printf("Versicolor\n");
        }

        break;

    case 2:
        printf("Please enter the x1, x2, x3, x4 and x5 values sequentially.");
        printf("\nx1:");
        scanf("%f",&x1);
        printf("\nx2:");
        scanf("%f",&x2);
        printf("\nx3:");
        scanf("%f",&x3);
        printf("\nx4:");
        scanf("%f",&x4);
        printf("\nx5:");
        scanf("%f",&x5);

        if( dt2a(x1,x2,x3,x4,x5) == dt2b(x1,x2,x3,x4,x5) ){  // Checks if decision trees had came to the same result or not.
            printf("The decision trees had came to the same result:");
            printf("%f",dt2a(x1,x2,x3,x4,x5));
        }else{
            printf("The result of the first decision tree: %f\n",dt2a(x1,x2,x3,x4,x5));
            printf("The result of the second decision tree: %f\n",dt2b(x1,x2,x3,x4,x5));
        }
        break;

    case 3:
        printf("Please enter the data required sequentially.\n\n");

        printf("Please enter your Body-Mass Index value (min 18.0, max 35.0):");
        scanf("%f",&BMI);

        printf("Please enter your shoe size(min 34.0 max 50.0)");
        scanf("%f",&shoeSize);

        printf("Please enter 1 for Male and 0 for Female:");
        scanf("%d",&sex);

        printf("Please enter your bone-type.\n1-Very thin.\n2-Thin\n3-Average\n4-Thick\n5-Very thick.\n");
        scanf("%d",&boneType);

        printf("Please enter your daily activity level.\n1-I sit most of the day.\n2-I try to be active but I end up being passive during the day.\n3-I am active as much as a regular person.\n4-I have an active lifestyle.\n5-I have an active lifestyle and exercise on a regular basis.\n");
        scanf("%d",&activityLvl);

        if( dt3a(BMI, shoeSize, sex, boneType, activityLvl) == dt3b(BMI, shoeSize, sex, boneType, activityLvl) ){ // Checks if decision trees had came to the same result or not.
            printf("The decision trees had came to the same result:");

            // Prints the answers corresponding to the char values returned by the functions.
            if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'x') printf("Endomorph.\n");
            else if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'y') printf("Mesomorph.\n");
            else if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'z') printf("Ectomorph.\n");


        }else{
            printf("\nDecision trees had came to different results:\n");

            printf("The result of the first decision tree:\n");
            // Prints the answers corresponding to the char values returned by the functions.
            if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'x') printf("Endomorph\n");
            else if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'y') printf("Mesomorph\n");
            else if(dt3a(BMI, shoeSize, sex, boneType, activityLvl) == 'z') printf("Ectomorph\n");

            printf("\nThe result of the second decision tree:\n");
            if(dt3b(BMI, shoeSize, sex, boneType, activityLvl) == 'x') printf("Endomorph\n");
            else if(dt3b(BMI, shoeSize, sex, boneType, activityLvl) == 'y') printf("Mesomorph\n");
            else if(dt3b(BMI, shoeSize, sex, boneType, activityLvl) == 'z') printf("Ectomorph\n");
        }



        break;
    default:
        printf("There is no such operation for %d",operationCode);


    }
    /* Ask for the problem selection (1,2,3) .....  */

    /* Get the input from the user for the first problem, i.e., to test dt1a and dt1b */
    /* Compare performances and print results */

    /* Get the input from the user for the second problem, i.e., to test dt2a and dt2b */
    /* Compare performances and print results */

    /* Get the input from the user for the third problem, i.e., to test dt3a and dt3b */
    /* Compare performances and print results */

}
