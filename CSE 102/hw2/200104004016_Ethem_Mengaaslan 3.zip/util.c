#include <stdio.h>
#include <math.h>
#include "util.h"

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, int s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}


char dt1a(float PL, float PW){ // The first decision tree for the part 1.

    //x for Setosa, y for Virginica, z for Versicolor.

    char result;
    int i = 0;



    if( PL < 2.45 ){
            result = 'x';
    }
    else if( PW > 1.75 ){
            result = 'y';
    }
    else if( PL < 4.95 && PW < 1.65 ){
         result = 'z';
    }
    else result = 'y';

    return result;


}

char dt1b(float PL, float PW){ // The second decision tree for the part 1.

    char result;
    int i = 0;



    if( PL < 2.55 ){
            result = 'x';
    }
    else if( PW < 1.69 && PL < 4.85){
            result = 'z';
    }
    else{
        result = 'y';
    }

    return result;


}

double dt2a(float x1, float x2, float x3, float x4, float x5 ){ // The first decision tree for the part 2.

    float result = 0;

    if( x1 < 31.5 && x2 > -2.5 ){
        result = 5.0;
    }else if ( x1 < 31.5 && x2 < -2.5){

            if( x2 - 0.1 <= x1 && x1 <= x2 + 0.1 ){
                result = 2.1;
            }else result = -1.1;

    }else if( -1 <= x3 && x3 <= 2){
        result = 1.4;
    }else if( x4 && x5 ){
        result = -2.23;
    }else result = 11.0;

    return result;

}

double dt2b(float x1, float x2, float x3, float x4, float x5 ){ // The second decision tree for the part 2.

    float result = 0;

    if( 12 < x1 && x1 < 22 && x3 > (5/3) ){
        result = -2.0;
    }else if ( 12 < x1 && x1 < 22 && x3 < (5/3) ){

            if( x1 - 0.1 <= x3 && x3 <= x1 + 0.1 ){
                result = 1.01;
            }else result = -8;

    }else if( x4 && x5 ){
        result = -1;
    }else if( -1 <= x2 && x2 <= 2 ){
        result = -1/7;
    }else result = sqrt(2)/3.0;

    return result;



}

char dt3a(float BMI, float shoeSize, int sex, int boneType, int activityLvl){ // First decision tree for the part 3. This decision tree classifies given data and decides
                                                                              // a person's body type is endomorph, mesomorph or ectomorph.
    //endomorph : x
    //mesomorph : y
    //ectomorph : z

    char result;

    if(sex == 1){
        if(shoeSize > 45){
            result = 'x';
        }else if(activityLvl == 1 || activityLvl == 2 || activityLvl == 3){

            if(BMI > 29){
                result = 'x';
            }else if( boneType == 1 || boneType == 2 ){
                if(activityLvl == 4 || activityLvl == 5){
                    result = 'y';
                }else{
                    result = 'z';
                }
            }else{
                result = 'y';
            }
        }else{
            result = 'x';
        }

    }else if(sex == 0){
        if(shoeSize > 39){
            result = 'x';
        }else if(BMI < 27){
            if(shoeSize < 37){
                result = 'z';
            }else{
                result = 'y';
            }
        }else{
            if(activityLvl == 1 || activityLvl || 2){
                result = 'x';
            }else{
                if(boneType == 1 || boneType == 2 || boneType == 3){
                    result = 'y';
                }else{
                    result = 'x';
                }
            }
        }
    }


    return result;
}

char dt3b(float BMI, float shoeSize, int sex, int boneType, int activityLvl){ // First decision tree for the part 3. This decision tree classifies given data and decides
                                                                              // a person's body type is endomorph, mesomorph or ectomorph.

    //endomorph : x
    //mesomorph : y
    //ectomorph : z

    char result;

    if(sex == 1){
        if(activityLvl == 1 || activityLvl == 2){
            result = 'x';
        }else if(shoeSize < 45){
            if(boneType == 1 || boneType == 2){
                if(activityLvl == 4 || activityLvl == 5){
                    result = 'y';
                }else{
                    result = 'z';
                }
            }else{
                if(shoeSize < 42){
                    result = 'z';
                }else{
                    result = 'y';
                }
            }
        }else{
            result = 'z';
        }
    }else{
        if(BMI < 28){
            if(shoeSize < 38){
                if(activityLvl == 1 || activityLvl == 2 || activityLvl == 3){
                    result = 'z';
                }else if(boneType == 4 || boneType == 5){
                    result = 'x';
                }else{
                    result = 'y';
                }
            }else{
                result = 'x';
            }
        }else if(boneType == 1 || boneType == 2){
            result = 'z';
        }else{
            result = 'x';
        }

    }

    return result;

}

