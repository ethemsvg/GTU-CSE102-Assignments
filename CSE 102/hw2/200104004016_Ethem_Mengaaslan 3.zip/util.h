#ifndef _UTIL_H_
#define _UTIL_H_

#define CLOSE_ENOUGH 0.001

/* Example decision tree - see the HW2 description */
//int dt0(int t, double p, double h, char s, int w);

char dt1a(float PL, float PW);
char dt1b(float PL, float PW);

double dt2a(float x1, float x2, float x3, float x4, float x5 );
double dt2b(float x1, float x2, float x3, float x4, float x5 );

/* Write the prototype of the functions implementing the decision trees for the third problem */
char dt3a(float BMI, float shoeSize, int sex, int boneType, int activityLvl);
char dt3b(float BMI, float shoeSize, int sex, int boneType, int activityLvl);

#endif /* _UTIL_H_ */
