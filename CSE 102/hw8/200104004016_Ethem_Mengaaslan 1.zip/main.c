#include <stdio.h>
#include <stdlib.h>
#include "util.h"



// Homework submission by Ethem Mengaaslan.

int main()
{

    int i=0;
    int *loop;
    int seqlen;
    int firstElement;
    int looplen;
    int digit=1;

    printf("Please enter sequence length:\n");
    scanf("%d",&seqlen);

    printf("Please enter the first element:\n");
    scanf("%d",&firstElement);

    int sequence[seqlen];


    loop = (int*)malloc(sizeof(int)*(seqlen/2));    // Allocating memory for the array which'll be storing the loop (if found) in the sequence.

    looplen = (seqlen / 2);                         // Starting length for the loop is the half of the length of the sequence.

    int *h;
    h=(int*)calloc(9,sizeof(int));                  // A histogram array has the size 9 because of the nine digits. We use calloc so it's filled with 0(zero)s.


    // We call the recursive check_loop_iterative function to see if there is a loop within the sequence generated with the given seqlen and firstElement values.

    check_loop_iterative(generate_sequence,firstElement,seqlen,loop,&looplen);


    if(looplen!=1 && looplen != 0){

        printf("\nLoop: {");
        for(i=0;i<looplen;i++){
            printf("%d",loop[i]);
                if(i<(looplen)-1){
                    printf(", ");
                }
        }
        printf("}\n");

    }

    // We call the hist_of_firstdigits function to fill the histogram array with the histogram of the numbers in the generated sequence, and print the histogram.

    hist_of_firstdigits(generate_sequence,firstElement,seqlen,h,digit);

    printf("\nHistogram of sequence: {");

    for(i=0;i<9;i++){
        printf("%d",h[i]);
        if(i<8){
            printf(", ");
        }
    }
    printf("}\n");



    return 0;
}


