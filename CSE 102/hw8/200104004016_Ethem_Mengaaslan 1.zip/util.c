#include <stdio.h>
#include <stdlib.h>
#include "util.h"
/*

Fills the *seq array with numbers starting from the xs and calculating the rest according to
the collatz conjecture, in a recursive way.

int xs: Starting element of the collatz conjecture.

int currentlen: Current length of the array (current number of numbers assigned in the empty *seq array.).

int seqlen: Length of the sequence (the max length value given by the user.).

int *seq: The array which'll be storing the numbers generated accordingly to the collatz conjecture.

*/
void generate_sequence(int xs, int currentlen, int seqlen, int *seq){

    seq[currentlen-1] = xs;
    if(currentlen != seqlen){

        // If the number is even, the next number is half of the current number value.
        if(xs % 2 == 0){
            xs = xs / 2;
            seq[currentlen] = xs;
            generate_sequence(xs,currentlen+1,seqlen,seq);

        // If the number is odd, the next number is 3 times + 1 of the current number value.
        }else if(xs % 2 != 0){

            xs = 3*xs + 1;
            seq[currentlen] = xs;
            generate_sequence(xs,currentlen+1,seqlen,seq);

        }

    }

}
/*

Checks whether the sequence of numbers has a loop inside, by calling the has_loop function to check for
any loops.

void (*f)(): for generate_sequence function to generate the sequence accordingly to collatz conjecture.

int xs: Starting element of the collatz conjecture.

int seqlen: Length of the sequence (the max length value given by the user.).

int *loop: The array which'll be storing the loop (if found).

int *looplen: Stores the size of the loop found.

*/
void check_loop_iterative(void (*f)(), int xs, int seqlen, int *loop, int *looplen){


    int *sequence;
    int i=0;
    static int check = 0;
    // Allocating memory for the sequence array.
    sequence=(int*)malloc(sizeof(int)*seqlen);

    (f)(xs, 1, seqlen, sequence);

    if(check == 0){
        printf("\nSequence: {");
    for(i=0;i<seqlen;i++){
        printf("%d",sequence[i]);
        if(i<seqlen-1){
            printf(", ");
        }
    }
    printf("}\n\n");
    }
    check++;

    int ls;
    int le;
    int result = 1;
    int temp_len = *looplen;




    result = has_loop(sequence,seqlen,temp_len,&ls,&le);

    // If no loop is found.
    if( result == 0 ){

        (*looplen)--;

        if(*looplen==1 || *looplen==0){
            printf("No loop found in the sequence.\n");
            return ;
        }

        check_loop_iterative(f,xs,seqlen,loop,looplen);

    // If a loop is found.
    }else if(result == 1){

        // Allocating memory for the array which'll be storing the loop, according to the length of
        // the loop found, and assigning the looped numbers into the loop array.
        *loop = (int*)malloc(sizeof(int)*(le-ls));

        for(i=0;i<(le-ls);i++){
            loop[i] = sequence[ls+i];

        }

    }

}
/*

Checks whether a given sequence has a loop with a given length, determining the starting and ending
indexes of the loop in the given sequence.

int *arr: The given sequence.

int n: Number of numbers the given sequence contains.

int len: The length of the loop function will look for.

int *ls: Starting index of the loop.

int *le: Ending index of the loop.

*/
int has_loop(int *arr, int n, int len, int *ls, int *le){

    int i,j;
    int flag = 0;
    int comparisons = 0;

    // Calculating the number of iterations will be made according to the size of the sequence and the length of the loop being looked for.
    if(n % 2 == 0){
        comparisons = 2*((n/2)-len)+1;
    }else{
        comparisons = 2*((n/2)-len)+2;
    }


    printf("Looking for a loop with length %d...\n",len);
    for(i=0;i<comparisons;i++){
        flag = 0; // The flag value is assigned 0 at the beggining of each comparison.
        for(j=i;j<i+len;j++){
            if(arr[j] != arr[j+len]){
                flag++; // If the flag value is corrupted by this line, the function will return 0, meaning no loop is found.
            }
        }
            if(flag == 0){
                        // If the flag value remains 0 after comparisons, it means that the elements match and there is a loop.

                // The ls and le values are assigned with the starting/ending points of the loop which has been found.
                *ls = i;
                *le = i+len;
                printf("\nA loop is detected with size %d.\nFirst Occurence: Starting index:%d Ending index:%d\n",len,*ls,(*le)-1);
                return 1;

            }

    }

    return 0;


}

/*
Creates a histogram of the first digits of every number in the generated collatz conjecture sequence.

void (*f)(): For generate_sequence to be called inside the function.

int xs: Starting element of the collatz conjecture.

int seqlen: Length of the sequence (the max length value given by the user.).

int *h: The array which'll be storing the histogram.

int digit: The digit which will be being seeked after, to incremenet the related histogram element.

        The function will recurse while incrementing the digit until the digit value is 9 and the histogram is fully updated.
        Therefore, the starting value of the digit must be 1 when calling this function in main.

*/

void hist_of_firstdigits(void (*f)(), int xs, int seqlen, int *h, int digit){

    int i = 0;


    int *sequence;
    sequence = (int*)malloc(sizeof(int)*seqlen);
    (f)(xs, 1, seqlen, sequence);

    int *firstDigits;
    firstDigits = (int*)malloc(sizeof(int)*seqlen);


    for(i=0;i<seqlen;i++){
        firstDigits[i] = first_digit(sequence[i]);
        //printf("%d. number:%d first digit:%d\n",i,sequence[i],firstDigits[i]);
    }

    for(i=0;i<seqlen;i++){

        if(firstDigits[i] == digit){
            h[digit-1]+=1;
        }

    }

    if(digit == 9){
        return;
    }

    hist_of_firstdigits(f,xs,seqlen,h,digit+1);

    }


/*

Returns the first digit of the number it takes.

int number: The number whose first digit will be detected.

*/

int first_digit(int number){

    int i = 0;

    if(number < 10){
        return number;
    }

    for(i=0;i<100;i++){

        number = number / 10;   // Basically divides the number by 10 until it becomes less than 10 (until only the first digit of the number remains).

        if(number < 10){

            return number;

        }

    }



}



