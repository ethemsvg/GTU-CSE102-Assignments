#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define BOARD_SIZ 15
#define WORD_SIZ 6

// Function declarations.

void print_board(char board[][BOARD_SIZ]);
void paint_found(char board[][BOARD_SIZ],char *word, int row, int column, int direction);
void fill_board_random_chars(char board[][BOARD_SIZ]);
void word_picker(char words[]);
void clean_board(char board[][BOARD_SIZ]);
void word_placer(char *word, char board[][BOARD_SIZ], int start_points[2], int direction[], int index);

int main(){

    srand(time(NULL));

    // Necessary variables.
    int i,j;
    int flag;
    char board[BOARD_SIZ][BOARD_SIZ];
    char words[7][WORD_SIZ];
    int start_point[2];
    int start_points_all[7][2];
    int direction;
    int directions_all[8];
    char row[WORD_SIZ];
    int column;
    char word_entry[WORD_SIZ];
    int moves = 3;
    int points = 0;
    int rowint;
    clean_board(board);
	printf("debug1");
    printf("The Picked Words Are:\n");
	printf("debug2\n");

    // Seven words are picked from the wordlist.txt file in this for loop block.
    for(i=0;i<7;i++){
        word_picker(words[i]);
        for(j=0;j<i;j++){
            if(strcmp(words[j],words[i]) == 0 ){
                i--;
            }
        }
        printf("%s\n",words[i]);
    }


    // The picked words are loaded into the board array in this for loop block.
    printf("\nThe words are being placed in the board..\n");
    for(i=0;i<7;i++){
        word_placer(words[i],board,start_points_all[i],directions_all,i);
    }

    for(i=0;i<7;i++){
        printf("%d %d %s\n",start_points_all[i][0],start_points_all[i][1],words[i]);
    }


    // First, it prints the answer key(board with only words and not any random character filling).
    print_board(board);

    // Then, it fills the board with random characters. The board will be printed and the game loop will be started in the do-while loop below.
    fill_board_random_chars(board);

    printf("\nSTART OF THE GAME...\n");

    // GAMEPLAY PART:
    do{
        print_board(board);
        flag = 0; // This flag is to check whether the user had found an actual word or made a mistake.
        printf("Enter coordinates and word:");
        scanf("%s",row); // Since the game is terminated when the user enters :q , the row value which is the first value entered is taken as a string and then transformed into an integer using typecasting.

        if(strcmp(":q",row) == 0){ // To terminate the game after :q input.
            printf("Total points: %d",points);
            break;
        }

        scanf("%d",&column);
        scanf("%s",word_entry);

        rowint = atoi(row); // The string row turns into an integer called rowint to be used in the functions.

        /*
         In the if block below, the input word is compared to all of the words in the words array (which contains 7 words in total.)
         If there is a match, the i value is used to get the coordinates of the starting point of that word since the arrays are built
         parallel to each other. And at the end, if the coordinates match with the input too, the player gets 2 points and the word is
         replaced with a bunch of X's.
         */

        for(i=0;i<7;i++){
            if(strcmp(words[i],word_entry) == 0){
                if( (start_points_all[i][0] == rowint )&& (start_points_all[i][1] == column) ){
                    paint_found(board,words[i],rowint,column,directions_all[i]);
                    strcpy(words[i],"$$$$$"); // This line is to prevent the user from entering the same coordinate and word and gaining points over and over
                    points+=2;                 // again. It simply overwrites the word which had been found with a random string so it wont be equal when compared
                    flag = 1;                   // with the input next round.
                    printf("Founded! You got 2 points!.Your total points:%d\n",points);

                }
            }
        }

        // If entry is wrong, moves gets decremented, and if player loses all of his/her moves, the total points are shown and game is terminated.
        if(flag != 1){
            moves--;
            printf("Wrong choice! You have %d moves left.\n", moves);

            if(moves == 0){
                printf("Total Points: %d",points);
            }
        }else if(points==14){
        	print_board(board);
                printf("Total Points: %d",points);
        }


    }while(strcmp(":q",row) != 0 && moves > 0 && points < 14); // The game is terminated if a player is out of moves, has reached 14 points, or entered :q .

    return 0;
}

/*
This function paints the word found by user with X characters.

char board[][BOARD_SIZ] : The 2D array which is the board, where the words which'll be painted lays on.
char *word: The word which'll be painted over.
int row: Row value of the word's starting point.
int column: Column value of the word's starting point.
int direction: Direction of the word, can have a value between 1 and 8, each representing a direction.(More about this on word_placer function comment.).

*/
void paint_found(char board[][BOARD_SIZ],char *word, int row, int column, int direction){

    int i,j;
    int length_of_word;

    // Length of the word is needed in order to arrange our loops to prevent the function from painting Xs on wrong characters.
    length_of_word = strlen(word);

    switch(direction){

    case 1: // top to bottom.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                row++;
        }
        break;
    case 2: // bottom to top.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                row--;
        }
        break;
    case 3: // left to right.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column++;
        }
        break;
    case 4: // right to left.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column--;
        }
        break;
    case 5: // left top to right bottom.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column++;
                row++;
        }
        break;
    case 6: // from right bottom to left top
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column--;
                row--;
        }
        break;
    case 7: // from right top to left bottom.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column--;
                row++;
        }
        break;
    case 8: //from left bottom to right top.
        for(i=0;i<length_of_word;i++){
                board[row][column] = 'X';
                column++;
                row--;
        }
        break;
    default:
        printf("error in default, please contact to the developer if you're seeing this line on your terminal screen.");
        break;

    }

}

/*
This function places random characters in the board array after the words have been placed.

This function simply checks every element of the array, if one containc a space (32 in ascii), it places a random character.
NOTE: At the beggining, every element of the array is filled with spaces by the clean_board function, in order to prevent any
garbage values messing up the program.

char board[][BOARD_SIZ] : The 2D array which is the board of the game.

*/
void fill_board_random_chars(char board[][BOARD_SIZ]){

    int i,j;

    for(i=0;i<BOARD_SIZ;i++){
        for(j=0;j<BOARD_SIZ;j++){
            if(board[i][j] == 32){
                board[i][j] =  97 + (rand() % 26);

            }
        }
    }

}

/*
This function picks a word from the given .txt file containing 50 words.
NOTE: This function is only for picking one single word, so in order to pick 7 words from the file (which is the number required for this game),
it is needed to be looped 7 times in the main function.

char words[]: The array where the picked word will be stored in.
*/

void word_picker(char words[]){
	
    int i,j,k;
    char slave[WORD_SIZ];
    int rand_index;

    FILE *fp;

    fp = fopen("wordlist.txt","r");

    rand_index = rand() % 49;

    /*
    This for loop goes from 0 to the random index generated by the line above, scanning the encountered words in a temp array
    called char slave[WORD_SIZ], and stores the desired word in the char words[] array which is the parameter of the function
    */
    for(i=0;i<rand_index+1;i++){
        fscanf(fp,"%s",words);
        if(i==rand_index){
            fscanf(fp,"%s",words);
        }
        
    }

    fclose(fp);


}

/*
This function simply assigns ' ' (space, who's ascii value is 32) in every block of the array, to prevent any garbage value problems.

char board[][BOARD_SIZ] : The 2D array which is the board of the game.

*/
void clean_board(char board[][BOARD_SIZ]){

    int i,j;

    for(i=0;i<BOARD_SIZ;i++){
        for(j=0;j<BOARD_SIZ;j++){
            board[i][j] = ' ';
        }
    }

}

/*
This function is for printing the 2D array on the terminal by looping through all of it's elements.

char board[][BOARD_SIZ] : The 2D array which is the board of the game.

*/

void print_board(char board[][BOARD_SIZ]){

    int i,j;
    printf("\n");
    for(i=0;i<BOARD_SIZ;i++){
        for(j=0;j<BOARD_SIZ;j++){
            printf("%c ",board[i][j]);
        }
        printf("\n");
    }
    printf("\n");

}

/*
This function is for placing the picked words into the board, with 8 possible directions decided randomly, and in random
locations on every run.

The directions are represented as numbers between 1 and 8 (what they represent are mentioned in the switch case block below in the function.)

The mechanism for placing a word on the board works like this:
    A random starting point and direction is picked.
    Word starts being assigned in the array through the given direction character by character, any encountering with other words is checked on every iteration of loop.
    If encountering is present, an other nested loop is started from 0 to i (the outside loops last value, which represents the number of characters placed until that moment.)
    The inside loop goes the opposite direction, assigning ' ' (space)s in the array, cleaning the board from the halfly-written word.
    A new random starting point is selected, and this process start all over until the word is completely placed in a spot.

char *word : The word which'll be placed on the board.

char board[][BOARD_SIZ] : The 2D array which is the board of the game, where all the words and random characters are stored.

int start_points[2] : This is a parallel array to the words[] array, which stores the starting point of the word placed. This is used for checking the users
entries during the game.

int direction[] : This is also a parallel array, storing the direction of the words, for checking the users entries during the game.

int index : Index of the direction array which is being looped in the main function.

*/

void word_placer(char *word, char board[][BOARD_SIZ], int start_points[2], int direction[], int index){

    int i,j,k;
    int rand_column;
    int rand_row;
    int rand_direction;
    int length_of_word;


    length_of_word = strlen(word);

    rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed.
    rand_column = rand() % 15;

    rand_direction = (rand() % 8) + 1 ; // Determines what direction will the selected word will be placed in.

    // The starting points and the directions are stored in parallel arrays.
    start_points[0] = rand_row;
    start_points[1] = rand_column;
    direction[index] = rand_direction;

    switch(rand_direction){

    case 1: // top to bottom.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_row < 14 && rand_column < 14 && rand_row > 0 && rand_column > 0){
                board[rand_row][rand_column] = word[i];
                rand_row++; // Since this motion is top to bottom, the column value will stay the same.
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row-1][rand_column] = ' ';
                    rand_row--;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 2: // bottom to top.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_row < 14 && rand_column < 14 && rand_row > 0 && rand_column > 0){
                board[rand_row][rand_column] = word[i];
                rand_row--; // Since this motion is bottom to top, the column value will stay the same.
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row+1][rand_column] = ' ';
                    rand_row++;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }

        }
        break;
    case 3: // left to right.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_row < 14 && rand_column < 14 && rand_row > 0 && rand_column > 0){
                board[rand_row][rand_column] = word[i];
                rand_column++; // Since this motion is left to right, the row value will stay the same.
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row][rand_column-1] = ' ';
                    rand_column--;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 4: // right to left.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_row < 14 && rand_column < 14 && rand_row > 0 && rand_column > 0){
                board[rand_row][rand_column] = word[i];
                rand_column--; // Since this motion is right to left, the row value will stay the same.
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row][rand_column+1] = ' ';
                    rand_column++;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 5: // left top to right bottom.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_column > 0 && rand_column < 14 && rand_row > 0 && rand_column < 14){
                board[rand_row][rand_column] = word[i];
                rand_column++;
                rand_row++;
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row-1][rand_column-1] = ' ';
                    rand_column--;
                    rand_row--;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 6: // from right bottom to left top
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_column > 0 && rand_column < 14 && rand_row > 0 && rand_column < 14){
                board[rand_row][rand_column] = word[i];
                rand_column--;
                rand_row--;
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row+1][rand_column+1] = ' ';
                    rand_column++;
                    rand_row++;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 7: // from right top to left bottom.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_column > 0 && rand_column < 14 && rand_row > 0 && rand_column < 14){
                board[rand_row][rand_column] = word[i];
                rand_column--;
                rand_row++;
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row-1][rand_column+1] = ' ';
                    rand_column++;
                    rand_row--;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    case 8: //from left bottom to right top.
        for(i=0;i<length_of_word;i++){
            if((board[rand_row][rand_column]== ' ' )&& rand_column > 0 && rand_column < 14 && rand_row > 0 && rand_column < 14){
                board[rand_row][rand_column] = word[i];
                rand_column++;
                rand_row--;
            }else{
                for(j=0;j<i;j++){ // This loop cleans the letters if the word doesn't fit in the board.
                    board[rand_row+1][rand_column-1] = ' ';
                    rand_column--;
                    rand_row++;
                }
                rand_row = rand() % 15;    // Determines the starting point of the word which'll be placed if the previously picked place is not available.
                rand_column = rand() % 15;
                start_points[0] = rand_row;
                start_points[1] = rand_column;
                i=-1;
            }
        }
        break;
    default:
        printf("error in default");
        break;

    }




}

