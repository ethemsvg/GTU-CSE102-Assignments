/*
	Homework submission by Ethem Mengaaslan.
	GTU CSE 102 HW9.
*/

#include <stdio.h>
#include <stdlib.h>

// Union for getting Person inputs.
typedef union{
    int id;
    char name[50];
    char address[50];
    int phone;

}Person_u;

// Union for getting Loan inputs.
typedef union{
    float amount;
    float interestRate;
    int period;
}Loan_u;

// Struct for storing customer and loan details.
typedef struct{
    Person_u Customer;
    Loan_u Loans[3];
}BankAccount_s;

double calculateLoan(float amount, int period, float interestRate);
void newLoan(FILE *floans, int userid, int loanNum,int period, double loan);
void getReport(FILE* fcustomers, FILE* floans, int loanID, int whichLoan, int size, int reportOp);
void addCustomer(FILE *fcustomers,int users_index, int next_id, BankAccount_s accounts[]);
void listCustomers(int size, BankAccount_s accounts[]);
double calculateLoan(float amount, int period, float interestRate);

int main()
{

    printf("\n========================================\n");
    printf("Welcome to the Bank Management System\n");
    printf("========================================\n");

    int operation;
    char slave[200];

    // The file pointers are created in this section, along with the all necessary variables.
    FILE *fcustomers;
    FILE *floans;
    // The user accounts are stored in this array.
    BankAccount_s accounts[50];

    // These static integers are incremented by one every time a user account is created, therefore limiting the account number by a maximum of 50.
    static int users_index = 0;
    static int next_id = 2;
    int j;
    int i;
    int counter = 0;
    int reportOp;
    int loanPeriods[50];
    int loanID;
    float tempAmount;
    float tempIntRate;
    int tempPeriod;
    int whichLoan;
    int fileID;
    int fileWhichLoan;
    double filePeriod;
    double fileLoan;
    int noLoansCheck = 0;
    char slave1[50];
    char slave2[50];
    char slave3[50];
    char slave4[50];
    int slave5;
    int loanAvailable = 1;

   // To get the current number of customers, this while loop below is used. This is for determining the current id number of the account which'll be created next.
    fcustomers = fopen("customers.txt","a+");
    floans = fopen("loans.txt","a+");

    fseek(fcustomers,0,SEEK_SET);
    fseek(floans,0,SEEK_SET);


    while(!feof(fcustomers)){
            fscanf(fcustomers,"%[^\n]%*c",slave);
            counter++;
    }
    counter = counter/4;
    counter--;
    next_id+=counter;

    fclose(fcustomers);
    fclose(floans);

    // The Menu
    printf("1. List All Customers\n2. Add New Customer\n3. New Loan Application\n4. Report Menu\n5. Exit System\n");
    fflush(stdin);
    scanf("%d",&operation);

    if(operation==5){
        printf("Exiting the program..");
    }

    // While the operation is not 5 (which means exit), this while loop keeps on going.
    while(operation != 5){

        fcustomers = fopen("customers.txt","a+");
        floans = fopen("loans.txt","a+");

        switch(operation){

        case 1:
	//Case 1 lists the usernames in the LOCAL SESSION, which means the accounts which are created in this session.
            listCustomers(users_index,accounts);
            break;

        case 2:
        //Case 2 is for creating user accounts.
            addCustomer(fcustomers,users_index,next_id,accounts);
            users_index++;
            next_id++;
            break;
        case 3:
            fflush(stdin);
            printf("To apply for a loan, please enter User ID:\n");
            scanf("%d",&loanID);

	// Case 3 is for assigning loans to created users. It firstly check if there is a user with desired ID and if the loan is available or not.

            while( !feof(fcustomers) ){
            	    loanAvailable = 1;
                    noLoansCheck = 0;
                    fscanf(fcustomers,"%d\n %[^\n]s%d\n %[^\n]s",&fileID,slave1,&slave5,slave2);

                    if( fileID == loanID ){

                        do{
                        fflush(stdin);
                        printf("If this is your first loan enter 1, if second enter 2, if third enter 3.\n");
                        scanf(" %d",&whichLoan);

                        if(whichLoan < 1 || whichLoan > 3){
                            printf("A user can only get 3 loans. Please enter a value in the range [1,3].\n");
                        }
                        }while(whichLoan < 1 || whichLoan > 3);

                        while( !feof(floans) ){

                            fscanf(floans,"%d %d %lf %lf",&fileID,&fileWhichLoan,&fileLoan,&filePeriod);
                            if(fileID == loanID && fileWhichLoan == whichLoan ){

                                printf("Loan already has given.");
                                loanAvailable = 0;
                                break;
                            }


                        }
                        if(loanAvailable == 0){
                            break;
                        }

			// The necessary inputs are taken through the structs and unions and sent to the newLoan() function.
                        printf("Please enter the Amount:");
                        fflush(stdin);
                        scanf("%f",&accounts[loanID-1].Loans[whichLoan-1].amount);
                        tempAmount = accounts[loanID-1].Loans[whichLoan-1].amount;


                        printf("Please enter the Period:");
                        fflush(stdin);
                        scanf("%d",&accounts[loanID-1].Loans[whichLoan-1].period);
                        tempPeriod = accounts[loanID-1].Loans[whichLoan-1].period;

                        printf("Please enter the Interest Rate:");
                        fflush(stdin);
                        scanf("%f",&accounts[loanID-1].Loans[whichLoan-1].interestRate);
                        tempIntRate = accounts[loanID-1].Loans[whichLoan-1].interestRate;


                        newLoan(floans,loanID,whichLoan,tempPeriod,calculateLoan(tempAmount,tempPeriod,tempIntRate));



                        noLoansCheck++;

                        break;
                    }

                }

                if(loanAvailable == 1 && noLoansCheck == 0){
                    printf("User not found.\n");
                }







            break;
        case 4:
        // Case 4 is for showing the reports for Customer details and any selected Loan for existing customers.
            fflush(stdin);
            printf("1. Customers Report\n2. Loans Report\n");
            fflush(stdin);
            scanf("%d",&reportOp);
            getReport(fcustomers,floans,loanID,whichLoan,next_id,reportOp);

            break;
        case 5:
            printf("\nExitting the program...");
            break;
        default:
            printf("\nInvalid Entry.");
            break;

        }
	// After an iteration is complete, the menu shows up again and the client is asked for an input. The loop does not end until 5 or any other invalid entry is entered by the client.
        printf("\n========================================\n");
        printf("Welcome to the Bank Management System\n");
        printf("========================================\n");

        printf("1. List All Customers\n2. Add New Customer\n3. New Loan Application\n4. Report Menu\n5. Exit System\n");

        fclose(fcustomers);
        fclose(floans);
        fflush(stdin);
        scanf("%d",&operation);
        if(operation==5){
        	printf("Exiting the program..");
        }



    }

    return 0;
}

/*
* Records the user id , loan number, loan period and total loan into a text file .
*
*	FILE *floans: A pointer to the file.
*
*	int userid: ID of the user.
*
*	int loanNum: Number of the loan (1,2 or 3).
*
*	int period: Period of the loan (to calculate monthly payments).
*
*	double loan: The total loan calculated by a recursive function.
*
*/
void newLoan(FILE *floans, int userid, int loanNum,int period, double loan){

    fprintf(floans,"%d %d %.2f %d\n",userid,loanNum,loan,period);

    printf("User with ID:%d's %d. loan of $%.2f is assigned.\n",userid,loanNum,loan);


}
/*
* Creates a report of customer details or loan details of a selected user.
*
* 	FILE* fcustomers: A pointer to the file where customer details are stored.
*
* 	FILE* floans: A pointer to the file where loan details are stored.
*
* 	int loanID: ID of the user who'se loans will be reported.
*
* 	int whichLoan: Number of the loan (1,2 or 3) of the user.
*
* 	int size: Number of users to use in necessary loops inside the function.
*
* 	int reportOp: 1 for Customer Report, 2 for Loan Report.
*/
void getReport(FILE* fcustomers, FILE* floans, int loanID, int whichLoan, int size, int reportOp){

	    int i = 0;
	    int id;
	    char name1[50];
	    char name2[50];
	    char address1[50];
	    char address2[50];
	    int phone;
	    int j;
	    int slave;
	    int fileID;
    	    int fileWhichLoan;
      	    double filePeriod;
      	    double fileLoan;
      	    int noLoansCheck;


	// This loop iterates the total number of users in the database and prints their details.

	    if(reportOp == 1){
                printf("customers report:\n");
		   for(j=0;j<size-1;j++){

			fscanf(fcustomers,"%d\n",&id);
			printf("ID:%d\t",id);

			fscanf(fcustomers," %[^\n]s\n",address1);
			printf("Address:%s\t",address1);

			fscanf(fcustomers,"%d\n",&phone);
			printf("Phone:%d\t",phone);

			fscanf(fcustomers," %[^\n]s\n",name1);
			printf("Name:%s\n",name1);

		}
            }else if(reportOp == 2){
	// This section is for reporting the loans. The user enters id of user and number of the loan which'll be inspected.
                printf("Please enter which user you want to see the report of loans:");
                fflush(stdin);
                scanf("%d",&loanID);
                printf("Please enter which loan you want to get a report of:");
                fflush(stdin);
                scanf("%d",&whichLoan);

                noLoansCheck = 0;
                while( !feof(floans) ){

                    fscanf(floans,"%d %d %lf %lf",&fileID,&fileWhichLoan,&fileLoan,&filePeriod);

                    if(fileID == loanID && fileWhichLoan == whichLoan ){

                        printf("\nTotal Credit Value = %.2lf\n",fileLoan);
		// The total loan is divided into the period and monthly payment is calculated.
                        for(i=0;i<filePeriod;i++){
                            printf("%d. Monthly Installement = %.4lf\n",i+1,fileLoan/filePeriod);
                        }

                        noLoansCheck++;

                        break;
                    }

                }

                if(noLoansCheck == 0){
                // If there is no loans, an error message is shown.
                    printf("No loan found.");
                }

            }

}
/*
* 	This function adds customer to the database, getting the following inputs from the client: Address, Name, Phone Number. And also assigns
*  an ID to all of them according to the number of accounts which were created beforehand.
*
* 	FILE* fcustomers: A pointer to the file where customer details are stored.
*
* 	int users_index: The index of the array where the user data are stored, is calculated by the program automatically.
*
*	int next_id: The ID of the user account which is being added to the database, is calculated by the program automatically.
*
*	BankAccount_s accounts[]: The array of struct BankAccount_s, this array stores the user data (Only the names in this case since unions can only store one value).
*
*/
void addCustomer(FILE *fcustomers,int users_index, int next_id, BankAccount_s accounts[]){

    if(next_id >= 50){
   	printf("The database can only store up to 50 users.");
	return;
    }


    accounts[users_index].Customer.id = next_id;                        // The ID is assigned to the user.
    fprintf(fcustomers,"%d\n",accounts[users_index].Customer.id);        // The assigned ID is recorded to the customers.txt file.


    printf("Please enter Customer Address:");
    scanf(" %[^\n]%*c", accounts[users_index].Customer.address);         // The customer address is taken as input.
    fprintf(fcustomers,"%s\n",accounts[users_index].Customer.address);   // Customer address is recorded to the customers.txt file.

    printf("Please enter Customer Phone:");
    
    while(!scanf("%d", &accounts[users_index].Customer.phone)){			// The customer phone is taken as input.
        if(!scanf("%d", &accounts[users_index].Customer.phone) == 1){		// If the user enters an invalid input (for example a character string), they are asked again to give valid input.
            printf("Invalid entry. Please only enter digits for phone number.\nPlease enter Customer Phone:");
        while ((getchar()!='\n'));
        }
    }
    
    
    							                  
    fprintf(fcustomers,"%d\n",accounts[users_index].Customer.phone);     // Customer phone is recorded to the customers.txt file.

    printf("Please enter Customer Name:");
    scanf(" %[^\n]%*c", accounts[users_index].Customer.name);            // The customer name is taken as input.
    fprintf(fcustomers,"%s\n",accounts[users_index].Customer.name);     // Customer name is recorded to the customers.txt file.




}

/*
* This function lists customer names from the struct array, it only lists the names since unions in c can only store the last input they were given.
*
*	int size: Number of users.
*
*	BankAccount_s accounts[]: The struct array which contains unions which stores customer names.
*
*/
void listCustomers(int size, BankAccount_s accounts[]){

int j=0;
// Iterates the number of accounts.
    for(j=0;j<size;j++){
        printf("Customer Name: %s\n",accounts[j].Customer.name);
    }

}

/*
* This function calculates the loan with the inputs amount, period and interest rate RECURSIVELY.
*
*	float amount: Value of loan amount given by user.
*
*	int period: Period of the loan given by user.
*
*	float interestRate: Interest rate of the loan.
*
*/
double calculateLoan(float amount, int period, float interestRate){


    if(period == 1){
        return amount*(1+(interestRate/100));
    }else{
        return calculateLoan(amount,period-1,(interestRate/100))*(1+(interestRate/100));

    }


}

