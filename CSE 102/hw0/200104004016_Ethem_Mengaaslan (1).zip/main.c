#include <stdio.h>
#include "util.h"


int main() {

    /* A fractional number: 13/7 */
    int num1 = 13;
    int den1 = 7;
    /* A fractional number: 30/11 */
    int num2 = 30;
    int den2 = 11;
    /* An unitilized fractional number */
    int num3, den3;

    printf("First number: ");                                   // This section is going to print the values of calculations made with the hard-coded numbers 13/7 and 30/11.
    fraction_print(num1, den1);
    printf("\n");

    printf("Second number: ");
    fraction_print(num2, den2);
    printf("\n");

    printf("Addition: ");
    fraction_add(num1, den1, num2, den2, &num3, &den3);
    fraction_print(num3, den3);
    printf("\n");

    printf("Subtraction: ");
    fraction_sub(num1, den1, num2, den2, &num3, &den3);
    fraction_print(num3, den3);
    printf("\n");

    printf("Multiplication: ");
    fraction_mul(num1, den1, num2, den2, &num3, &den3);
    fraction_print(num3, den3);
    printf("\n");

    printf("Division: ");
    fraction_div(num1, den1, num2, den2, &num3, &den3);
    fraction_print(num3, den3);
    printf("\n");

    // From now on, this section of the code will ask for input and make calculations, then print the results.

    int num4, den4;     // the variables for getting an input from the user
    int num5, den5;

    int num6,den6;      // the variables for storing the result from the calculations made with user's input



     do{ // A do while loop in case the user enters 0 as a denominator value.

    printf("\n\nPlease enter the first fraction you want to do calculations with: (numerator and denominator sequentially)\n");
        scanf(" %d", &num4);
        scanf(" %d", &den4);

    printf("Please enter the second fraction you want to do calculations with: (numerator and denominator sequentially)\n");
        scanf(" %d", &num5);
        scanf(" %d", &den5);

        if(den4==0 || den5==0){
            printf("The denominator values can not be '0'. Please try again.\n");
        }
        }while(den4==0 || den5==0); // If the user enters 0 as denominator value, the program asks him/her to enter a valid value until him/her enter a valid value.

    printf("First number: ");
    fraction_print(num4, den4);
    printf("\n");

    printf("Second number: ");
    fraction_print(num5, den5);
    printf("\n");

    printf("Addition: ");
    fraction_add(num4, den4, num5, den5, &num6, &den6);
    fraction_print(num6, den6);
    printf("\n");

    printf("Subtraction: ");
    fraction_sub(num4, den4, num5, den5, &num6, &den6);
    fraction_print(num6, den6);
    printf("\n");

    printf("Multiplication: ");
    fraction_mul(num4, den4, num5, den5, &num6, &den6);
    fraction_print(num6, den6);
    printf("\n");

    printf("Division: ");
    fraction_div(num4, den4, num5, den5, &num6, &den6);
    fraction_print(num6, den6);
    printf("\n");

    /*
     TODO: Complete this code to read two fractional numbers and print their
             multiplication and division results...
    */

    return(0);
}
