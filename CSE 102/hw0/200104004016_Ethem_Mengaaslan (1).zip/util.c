#include <stdio.h>
#include "util.h"

void fraction_print(int numerator, int denominator) {
    printf("%d//%d", numerator, denominator);
}  /* end fraction_print */

void fraction_add(int n1, int d1, int n2, int d2, int * n3, int * d3) {         // this function add's two fraction numbers.
    *n3 = n1*d2 + n2*d1;
    *d3 = d1*d2;
    fraction_simplify(n3, d3);
} /* end fraction_add */

void fraction_sub(int n1, int d1, int n2, int d2, int * n3, int * d3) {         // this function subtracts the second given fraction number from the first one.
    *n3 = n1*d2 - n2*d1;
    *d3 = d1*d2;
    fraction_simplify(n3, d3);
} /* end fraction_sub */

void fraction_mul(int n1, int d1, int n2, int d2, int * n3, int * d3) {         // this function multiplies the two given fraction numbers.
    *n3 = n1*n2;
    *d3 = d1*d2;

    fraction_simplify(n3, d3);
} /* end fraction_mul */

void fraction_div(int n1, int d1, int n2, int d2, int * n3, int * d3) {         // this function divides the first given fraction number with the second one given.
    *n3 = n1*d2;
    *d3 = n2*d1;

    fraction_simplify(n3, d3);
} /* end fraction_div */

/* Simplify the given fraction such that they are divided by their GCD */

void fraction_simplify(int * n, int * d) {

int i=0;
int border;
int gcd;

if(*n <= *d){                               //set a value for the limit of my for loop
    border = *d;
}else{
    border = *n;
}

if(border < 0){
    border = border * -1;
}

for(i=1;i<border+1;i++){                    // this for loop finds the gcd of two integers.

    if(*n%i==0 && *d%i==0){
        gcd = i;
    }

}

*n = *n / gcd;
*d = *d / gcd;

} /* end fraction_div */










