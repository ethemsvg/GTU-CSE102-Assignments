#include <stdio.h>
#include "util.h"

int find_divisible(int divisor, int botBorder, int topBorder){       // This function finds the first number which can be divisible to int divisor in the given range

    int i = 0;
    int firstResult = 0;

    for( i = botBorder ; i < topBorder ; i++ ){			// For loop to check for the numbers whose mod is zero when divided to the given divisor value.

        if( i % divisor == 0 ){
            firstResult = i;
            return firstResult;
        }
    }

    return -1; // if the value is -1, then the main function will print the error code -1 along with a text about the error.
}


int find_nth_divisible( int n , int firstResult, int divisor){	// This function jumps to the nth divisible number just like the find_divisible function.

    int i = 0;
    int counter = 0;
    int newResult = 0;

    for( i = 0 ; i < i+1 ; i++){
        firstResult +=divisor;
        counter++;
        if(counter == n){
            newResult = firstResult;
            return newResult;
        }
    }

}

int validate_identity_number( char identity_number[] ){		// This function checks whether an identity number is valid with some complicated calculations
									// The pseudo code for the calculations i mentioned: https://dinamiknetwork.com/tc-kimlik-no-dogrulama-algoritmasi/
    int i = 0;
    int size = 0;

    while(i < 11){

        if(identity_number[i] < 48 || identity_number[i] > 57 ){	// Checks if the input values are numbers by checking their ascii range.
            return 0;
        }

        i++;
        size++;
    }

    if(size != 11 || identity_number[0] == '0'){			// Checks if the input is not 11 digits long or the first digit is zero (both cases cause the id number
        return 0;							// to be unvalid).

    }

    int digitsOfIdentityNumber[11];

    for(i=0;i<11;i++){              //this is how i turn the typecasted int value of a character to the original digit value.
                                    // by subtracting the ascii value of 0 from the ascii value of the numbers as characters.
        digitsOfIdentityNumber[i] = (int)(identity_number[i]) - '0';
    }

    int sumOfEvenDigits = 0;
    int sumOfOddDigits = 0;

    sumOfEvenDigits = digitsOfIdentityNumber[1] + digitsOfIdentityNumber[3] + digitsOfIdentityNumber[5] + digitsOfIdentityNumber[7];
    sumOfOddDigits = digitsOfIdentityNumber[0] + digitsOfIdentityNumber[2] + digitsOfIdentityNumber[4] + digitsOfIdentityNumber[6] + digitsOfIdentityNumber[8];

    if((7*sumOfOddDigits - sumOfEvenDigits) % 10 != (digitsOfIdentityNumber[9])){	// Just another requirement for the id number to be valid. For further info please check
											// the link on the below comment blocks.
        return 0;
    }

    int sumOfAllDigits = 0;

    for(i=0;i<10;i++){
        //A for loop to calculate the sum of first 10 digits of the identity number.
        sumOfAllDigits = sumOfAllDigits + (digitsOfIdentityNumber[i]);
    }

    if(sumOfAllDigits % 10 != (digitsOfIdentityNumber[10])){

        return 0;
    }

return 1;

}

int create_customer( char identity_number[] , int password ){			// Takes an id number value, and if the id number value is marked valid by the 
											// validate_iddentity_number function, it asks for a password and create a user
    FILE *fp;										// by storing the values in a .txt file as a database.
    fp = fopen("customeraccount.txt","w");

    if(fp==NULL){			// for any kind of file errors, this block prevent the code to crash.
        printf("file opening error");
        return 0;
    }

    fprintf(fp,"%s,%d",identity_number,password);

    fclose(fp);

}

int check_login( char identity_number[], int password ){				// Gets id and password values and compare them to the ones in the database (.txt file)
											// if they match the user gets logged in.
   FILE *fp;		
   fp = fopen("customeraccount.txt","r");
   char slaveChar;
   int truePassword;

   int i=0;

   for(i=0;i<11;i++){

    fscanf(fp, "%c",&slaveChar);
    if(slaveChar != identity_number[i]){			// The file gets read char by char and the value is stored in the slaveChar variable. Simultaniously the char
        printf("Invalid identity number or password");	// value gets compared to the input. If there is no mismatching, user logs in.
        return 0;
    }
   }
   fscanf(fp,"%c",&slaveChar); //this line skips over the ',' (comma) for further comparisons we will make.

   fscanf(fp,"%d",&truePassword);

   if(truePassword != password){
        printf("Invalid identity number or password");
        return 0;
   }

   return 1;

}

int withdrawable_amount(float cash_amount){	// This function gets a float input and returns a withdrawable integer output as we assume the atm only has 50,20 and 10 lira 
						// banknotes.
    int result = 0;
    int fifties = 0;
    int twenties = 0;
    int tens = 0;
    int i=0;

    for(i=0;i<i+1;i++){			// Counts the max number of 50 lira banknotes in the input value, stores them.
        if((cash_amount - 50)<0){
            break;
        }else{
            cash_amount-=50;
            fifties++;
        }
    }

    for(i=0;i<i+1;i++){			// Counts the max number of 20 lira banknotes in the input value, stores them.
        if((cash_amount - 20)<0){
            break;
        }else{
            cash_amount-=20;
            twenties++;
        }
    }

    for(i=0;i<i+1;i++){			// Counts the max number of 10 lira banknotes in the input value, stores them.
        if((cash_amount - 10)<0){
            break;
        }else{
            cash_amount-=10;
            tens++;
        }
    }

    printf("\nwithdrawable amount is: %d ",fifties*50 + twenties*20 + tens*10); // Sums the banknote values and prints the withdrawable amount.

}
















