#include <stdio.h>
#include "util.h"

int main()
{
    int divisor;
    int botBorder;
    int topBorder;
    int result1 = 0;
    int result2 = 0;
    int n;

    printf("Please enter the bottom border (X VALUE):\n");
    scanf(" %d",&botBorder);

    printf("Please enter the top border (Y VALUE):\n");
    scanf(" %d",&topBorder);

    printf("Please enter the divisor value (Z VALUE):\n");
    scanf(" %d", &divisor);



    result1 = find_divisible(divisor, botBorder, topBorder);

    if(result1 == -1){
        printf("There is no number in the boundaries as you wish.\n");
    }else printf("The first integer between %d and %d is %d\n\n",botBorder,topBorder,result1);



    printf("Please enter the number how many next\n");
    scanf("%d",&n);

    result2 = find_nth_divisible(n, result1, divisor);

    if(result2 > topBorder){
        printf("There is no number in the boundaries as you wish.\n");
        return -999;
    }else printf("The %d. number between %d and %d is %d\n",n+1,botBorder,topBorder,result2);

    printf("\n\n PART 2 \n");

    int i = 0;
    char tcKimlik[24];

    printf("please enter id number:\n");
    scanf(" %s", tcKimlik);


    if(validate_identity_number( tcKimlik) == 1){

        int password = 0;

        printf("Please enter a 4 digit password:\n");
        scanf("%d",&password);

        create_customer(tcKimlik, password);
    }

    printf("\n\n PART 3 \n");

    char TcGiris[24];
    int SifreGiris;

    printf("Welcome to login page, please enter id number and password sequentially.\n");

    printf("Id:");
    scanf("%s",TcGiris);
    printf("\nPassword:");
    scanf("%d",&SifreGiris);

    if(check_login(TcGiris,SifreGiris) == 1){ // Checks whether the login process is successfull and lets the user to enter a value if so.

        float money_amount;

        printf("Enter your withdraw amount:");
        scanf(" %fl", &money_amount);

        withdrawable_amount( money_amount );


    }






















}
