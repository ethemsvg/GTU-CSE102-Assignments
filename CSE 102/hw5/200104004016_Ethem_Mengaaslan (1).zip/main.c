#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14
// Functions.
int calculate(int (*f)(int), int (*k)(int));
int select_shape();
int select_calculator();
int calc_triangle(int mode);
int calc_quadrilateral(int mode);
int calc_circle(int mode);
int calc_pyramid(int mode);
int calc_cylinder(int mode);

//Two enumarated types for shape and calculator selection.
enum shapes{

    triangle = 1,
    quadrilateral,
    circle,
    pyramid,
    cylinder

};

enum calculators{

    area = 1,
    perimeter,
    volume

};

int main(){

// An empty do-while loop because whenever it checks the condition, it also runs the function and by that, it runs until the function returns 0 as output.
do{

}while(  calculate(select_shape,select_calculator) != 0 );


}


int calculate(int (*f)(),int (*k)()){


    int shape;
    int calculator;

//This loop continues to run until one of the shape or calculator values become zero, if so, the function exits the loop and returns zero, causing the do-while loop in the main to end.
    do{

//This sequence runs and takes the values from the input functions and store them in variables. Also returns 0 if one of the inputs are zero which mean exit the program.
    int shape = (*f)();
    if(shape == 0) return 0;
    int calculator = (*k)();
    if(calculator == 0) return 0;
//These are some conditions for special cases like calculating the volume of a 2 dimensional shape etc. .
    else if(shape == 1 && calculator == 3){
        printf("ERROR: You can not calculate the volume of a triangle. Please try again.\n");
        return 1;
    }else if(shape == 2 && calculator == 3){
        printf("ERROR: You can not calculate the volume of a quadrilateral. Please try again.\n");
        return 1;
    }else if(shape == 3 && calculator == 3){
        printf("ERROR: You can not calculate the volume of a circle. Please try again.\n");
        return 1;
    }
// A switch-case which runs the related function according to the inputs select_shape, with the parameter select_calculator.
    switch(shape){

    case 1:
        calc_triangle(calculator);
        return 1;
    case 2:
        calc_quadrilateral(calculator);
        return 1;
    case 3:
        calc_circle(calculator);
        return 1;
    case 4:
        calc_pyramid(calculator);
        return 1;
    case 5:
        calc_cylinder(calculator);
        return 1;
    case 0:
        return 0;
        break;
    default:
        break;
    }

}while(shape != 0 && calculator != 0); // End of the do-while loop.

//If the loop is terminated, the function returns 0 and the loop in the main function also gets terminated.
return 0;

}

//This function gets an input about which shape will the calculations be made on an returns it for being used in int calculate() function.
int select_shape(){

enum shapes shp;
// A menu for the user for better user experience.
printf("\n\nWelcome to the geometric calculator!!\n\n");
printf("Select a shape to calculate:\n");
printf("------------------------------\n");
printf("1. Triangle\n2. Quadrilateral\n3. Circle\n4. Pyramid\n5. Cylinder\n0. Exit\n");
printf("------------------------------\n");
printf("Input: ");

//This block gets an input and asks the user to enter again if they enter an input other than a positive number or zero(inputs like chars or negative numbers are invalid entries.)

/*   WARNING : AN IMPORTANT EXPLANATION ABOUT A MECHANISM USED IN THIS PROGRAM FREQUENTLY

This entry checking mechanism is used for every input for the rest of the code.
The other ones wont have any comment but a simple one pointing here.

This block of code checks the return value of scanf, and according to the return value,
1. Prints an error message
2. Clears the buffer with "getchar()!='\n'" mechanism
3. Asks for the input over an over until the user enters a valid input.


The first while loop checks the code for any character entry, on the other hand, the while block
which come after the first while loop, checks the input for any negative values. It checks the input
which is known not a character (but not known if positive or negative value), for negativity.
If it is negative, the while block runs the while loop first used again, thereby getting the input again
but not forgetting to control it for any char entries                                                   */

// START OF THE CODE BLOCK MENTIONED IN THE COMMENT BLOCK ABOVE.
while(!scanf("%d", &shp)){
    if(!scanf("%d", &shp) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}
while(shp < 0 || shp > 5){ // the shp > 5 is only for the select_shape function and creates a border of [0,5] of inputs.
        printf("Invalid entry. Please enter one of the options.\n");

while(!scanf("%d", &shp)){
    if(!scanf("%d", &shp) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}
// END OF THE CODE BLOCK MENTIONED IN THE COMMENT BLOCK ABOVE.

// A basic switch statement for returning value to be used in the calculate function
switch(shp){

case 1:
    return shp;
case 2:
    return shp;
case 3:
    return shp;
case 4:
    return shp;
case 5:
    return shp;
case 0:
    printf("exiting program..");
    return shp;
default:
    printf("Invalid entry, Please enter a positive integer or 0 to exit.");
    return 1;

}

}

//This function gets an input to determine which aspect of the selected shape will be calculated an returns it for being used in int calculate() function.
int select_calculator(){

enum calculators calc;

printf("\n\nSelect calculator:\n");
printf("------------------------------\n");
printf("1. Area\n2. Perimeter\n3. Volume\n0. Exit\n");
printf("------------------------------\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%d", &calc)){
    if(!scanf("%d", &calc) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));//Clears the buffer
    }
}

while(calc < 0 || calc > 3){ // the calc > 3 is only for the select_shape function and creates a border of [0,3] of inputs.
        printf("Invalid entry. Please enter one of the options.\n");

while(!scanf("%d", &calc)){
    if(!scanf("%d", &calc) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}


// A basic switch-case for returning the calculator value which will be used in calculate function.
switch(calc){

case 1:
    return calc;
case 2:
    return calc;
case 3:
    return calc;
case 0:
    printf("exiting program..");
    return calc;
default:
    printf("Invalid entry, Please enter a positive integer or 0 to exit.");
    return 1;

}

}

// This function calculates the area and perimeter values of a triangle by getting the sides and the operation(area/perimeter) as input.
int calc_triangle(int mode){

float side1, side2, side3;
float s;
float area;
float perimeter;

do{

printf("Please enter 3 sides of the triangle:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side1)){
    if(!scanf("%f", &side1) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side1 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side1)){
    if(!scanf("%f", &side1) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side2)){
    if(!scanf("%f", &side2) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side2 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side2)){
    if(!scanf("%f", &side2) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side3)){
    if(!scanf("%f", &side3) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side3 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side3)){
    if(!scanf("%f", &side3) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Perimeter is calculated below line, and the validity of the triangle is being checked (the sum of 2 side values cannot be less than or equal the other one):
perimeter = side1+side2+side3;
if( perimeter/2 < side1 || perimeter/2 < side2 || perimeter/2 < side3 ){
    printf("Please enter a valid triangle\n");
}else if(side1<=0 || side2<=0 || side2<=0 ){
    printf("Error, Please enter a valid entry\n");
}

}while(perimeter/2 < side1 || perimeter/2 < side2 || perimeter/2 < side3);


//HERON'S FORMULA is used in this function. Below is the s value for the Heron's Formula.
s = (side1+side2+side3)/2;

//Area and perimeter are calculated in the switch structure below.
switch(mode){

case 1:
    area = sqrt(s*(s-side1)*(s-side2)*(s-side3));
    printf("Area of TRIANGLE : %.2f",area);
    return area;
    break;
case 2:
    perimeter = side1 + side2 + side3;
    printf("Perimeter of TRIANGLE : %.2f",perimeter);
    return perimeter;
case 0:
    printf("exiting..");
    break;
default:
    break;
}



}
// This function calculates the area and perimeter values of a quadrilateral by getting the sides and the operation(area/perimeter) as input.

int calc_quadrilateral(int mode){

float s;
float side1,side2,side3,side4;
float perimeter;
float area;

printf("Please enter 4 sides of the quadrilateral:\n");


// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side1)){
    if(!scanf("%f", &side1) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side1 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side1)){
    if(!scanf("%f", &side1) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side2)){
    if(!scanf("%f", &side2) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side2 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side2)){
    if(!scanf("%f", &side2) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side3)){
    if(!scanf("%f", &side3) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side3 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side3)){
    if(!scanf("%f", &side3) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &side4)){
    if(!scanf("%f", &side4) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

while(side4 <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &side4)){
    if(!scanf("%f", &side4) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}
// Switch structure calculates the area and the perimeter of the quadrilateral.
switch(mode){
case 1:
    // BRAHMAGUPTA'S FORMULA is used here to calculate the area.
    area = sqrt((s-side1)*(s-side2)*(s-side3)*(s-side4));
    printf("Area of the QUADRILATERAL is %.2f", area);
    return area;
case 2:
    perimeter = side1+side2+side3+side4;
    printf("Perimeter of the QUADRILATERAL is %.2f",perimeter);
    return perimeter;
default:
    printf("in default, for debugging");
    break;

}

}


// This function calculates the area and perimeter values of a circle by getting the radius and the operation(area/perimeter) as input.
int calc_circle(int mode){

float area;
float perimeter;
float radius;

printf("please enter the radius of the circle:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
while(!scanf("%f", &radius)){
    if(!scanf("%f", &radius) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}
while(radius <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &radius)){
    if(!scanf("%f", &radius) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}
// Switch structure that calculate the area and the perimeter with the given radius values.
switch(mode){

case 1:
    area = PI*radius*radius;
    printf("Area of CIRCLE is %.2f",area);
    return area;
case 2:
    perimeter = 2*PI*radius;
    printf("Perimeter of CIRCLE is %.2f",perimeter);
    return perimeter;
default:
    printf("in circle default, for debugging");
    break;
}

}

// This function calculates the area , perimeter and volume values of a pyramid by getting the necesarry values (base side, height, slant height etc. ) and the operation(area/perimeter/volume) as input.
int calc_pyramid(int mode){

float base_surface;
float lateral_surface;
float surface_area;
float volume;
float base_side;
float slant_height;
float height;
float base_perimeter;

// Switch structure which calculate the area,perimeter and volume of the pyramid.
switch(mode){

case 1:
    printf("Please enter the base side and the slant height of the pyramid:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &base_side)){
        if(!scanf("%f", &base_side) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }
    while(base_side <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &base_side)){
    if(!scanf("%f", &base_side) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &slant_height)){
        if(!scanf("%f", &slant_height) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

        while(slant_height <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &slant_height)){
    if(!scanf("%f", &slant_height) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}
    base_surface = base_side * base_side;
    lateral_surface = 2*base_side*slant_height;
    surface_area = base_surface+lateral_surface;

    printf("Base surface area of the pyramid is %.2f\n",base_surface);
    printf("Lateral surface area of the pyramid is %.2f\n",lateral_surface);
    printf("Surface area of the pyramid is %.2f\n",surface_area);

    return surface_area;
case 2:
    printf("Please enter the base side of the pyramid:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &base_side)){
        if(!scanf("%f", &base_side) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

    while(base_side <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &base_side)){
    if(!scanf("%f", &base_side) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

    //scanf("%f",&slant_height);

    base_perimeter = 4*base_side;
    printf("Base perimeter of the pyramid is %.2f",base_perimeter);
    return base_perimeter;
case 3:
    printf("Please enter the base side and the slant height of the pyramid:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &base_side)){
        if(!scanf("%f", &base_side) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

    while(base_side <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

    while(!scanf("%f", &base_side)){
        if(!scanf("%f", &base_side) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &height)){
        if(!scanf("%f", &height) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

    while(height <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &height)){
    if(!scanf("%f", &height) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

    volume = (base_side*base_side*height)/3;
    printf("Volume of the pyramid is %.2f",volume);
    return volume;
default:
    printf("pyramid default, for debugging");
    break;
}

}

// This function calculates the area , perimeter and volume values of a cylinder by getting the radius and height values and the operation(area/perimeter/volume) as input.
int calc_cylinder(int mode){

float volume;
float base_surface;
float lateral_surface;
float surface_area;
float radius;
float height;
float base_perimeter;

printf("Please enter the radius and the height of the cylinder:\n");

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
    while(!scanf("%f", &radius)){
        if(!scanf("%f", &radius) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

    while(radius <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &radius)){
    if(!scanf("%f", &radius) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}

// Input checking for validity. READ THE COMMENT BLOCK ON LINE 114 FOR DETAILED INFO.
        while(!scanf("%f", &height)){
        if(!scanf("%f", &height) == 1){
            printf("Invalid entry. Please enter only positive numbers.\n");
        while ((getchar()!='\n'));
        }
    }

    while(height <= 0){
        printf("Invalid entry. Please enter only positive numbers.\n");

while(!scanf("%f", &height)){
    if(!scanf("%f", &height) == 1){
        printf("Invalid entry. Please enter only positive numbers.\n");
    while ((getchar()!='\n'));
    }
}

}
//Switch structure that calculates the area, perimeter and the volume of the cylinder.
switch(mode){

case 1:
    base_surface = PI*radius*radius;
    lateral_surface = 2*PI*radius*height;
    surface_area = 2*PI*radius*(radius+height);
    printf("Base surface area of the CYLINDER is %.2f\n",base_surface);
    printf("Lateral surface area of the CYLINDER is %.2f\n",lateral_surface);
    printf("Surface area of the CYLINDER is %.2f\n",surface_area);
    return surface_area;
case 2:
    base_perimeter = 2*PI*radius;
    printf("Base perimeter of the CYLINDER is %.2f\n",base_perimeter);
    return base_perimeter;
case 3:
    volume = PI*radius*radius*height;
    printf("Volume of the CYLINDER is %.2f\n",volume);
    return volume;
default:
    printf("cylinder default, for debugging");
    break;
}

}





