#include <stdio.h>
#include <math.h>

int sum_or_multi_caller(int opFlag, int oddEvenFlag, int n1, int n2);
int multi(int n1, int n2, int oddEvenFlag);
int sum(int n1, int n2, int oddEvenFlag);
void write_file(int input);
void print_file();
void sort_file();
int prime_check_caller_function(int a);
int isPrime(int a);




int main(){

int opSelection;

//Variables for part1:
int opFlag;
int oddEvenFlag;
int n1,n2;

//Variables for part2:
int a;
int i=0;



printf("Please enter the operation you want to perform.\n1. Calculate sum/multiplication between two numbers.\n2. Calculate prime numbers.\n3. Show number sequence in file.\n4. Sort number sequence in file.");
scanf("%d",&opSelection);

switch(opSelection){

    case 1:
        printf("Please enter 0 for addition and 1 for multiplication:");
        scanf("%d",&opFlag);

        printf("Please enter 0 for even numbers and 1 for odd numbers:");
        scanf("%d",&oddEvenFlag);

        printf("Please enter two different numbers:");
        scanf("%d",&n1);
        
        //NEGATIVE CHECK AREA
        if(n1 < 0){
    		do{
        		printf("Input value cannot be negative. Please try again.");
        		scanf("%d",&n1);
    		}while(n1 < 0);
    	}
        //NEGATIVE CHECK AREA
        
        scanf("%d",&n2);
        //NEGATIVE CHECK AREA
        if(n1 < 0){
    		do{
        		printf("Input value cannot be negative. Please try again.");
        		scanf("%d",&n1);
    		}while(n1 < 0);
    	}
        //NEGATIVE CHECK AREA  
        
        sum_or_multi_caller(opFlag, oddEvenFlag, n1, n2);
        //printf("The result is: %d",sum_or_multi_caller(opFlag, oddEvenFlag, n1, n2));
        break;
    case 2:
        //xxx
        printf("Please enter an integer: ");
        scanf("%d",&a);

        for(i = 2; i < a; i++){

            prime_check_caller_function(i);

        }

        break;
    case 3:
        //xxx
        print_file();
        break;
    case 4:
        //xxx
        sort_file();
    case 5:
        break;
    default:
        printf("Unvalid operation entry.");
        break;
}

}

int sum_or_multi_caller(int opFlag, int oddEvenFlag, int n1, int n2){ // This function calls the necessary functions to calculate the sum or multiplication values of odd or even numbers in a given range according to its input values.

    long long int result;

    if(opFlag == 1){

        result = multi(n1,n2,oddEvenFlag);
        write_file(result);
        return result;

    }else if(opFlag == 0){

        result = sum(n1,n2,oddEvenFlag);
        write_file(result);
        return result;

    }else{

        printf("Error inside sum_or_multi_caller function.");
        return -999;

    }


}

int multi(int n1, int n2, int oddEvenFlag){ // Calculates the multiplication of the odd or even numbers in the given range.


    int i = 0;
    int topBorder;
    int botBorder;
    long long int result = 1;

    if(n1>n2){
        topBorder = n1;
        botBorder = n2;
    }else{
        topBorder = n2;
        botBorder = n1;
    }

    printf("Result is:\n");


    for( i=botBorder; i<topBorder; i++ ){


            if(oddEvenFlag == 1){
                //multiplying the odd numbers in the given range.
                if( i % 2 != 0){
                    printf("%d",i);

                    if(i<topBorder-1){
                    printf("*");
                    }

                    result *= i;
                }
            }else if(oddEvenFlag == 0){
                //multiplying the even numbers in the given range.
                if( i % 2 == 0){
                    printf("%d",i);

                    if(i<topBorder-1){
                    printf(" * ");
                    }

                    result *= i;
                }
            }else printf("Invalid flag value.");



    }
            printf("= %lld", result);

            return result;


}


int sum(int n1, int n2, int oddEvenFlag){ // Calculates the sum of the odd or even numbers in the given range.


    int i = 0;
    int topBorder;
    int botBorder;
    long long int result = 0;

    if(n1>n2){
        topBorder = n1;
        botBorder = n2;
    }else{
        topBorder = n2;
        botBorder = n1;
    }

    printf("Result is:\n");

    for( i=botBorder; i<topBorder; i++ ){

            if(oddEvenFlag == 1){
                //adding the odd numbers in the given range.
                if( i % 2 != 0){

                    printf("%d",i);
                    if(i<topBorder-1){
                    printf(" + ");
                    }

                    result += i;
                }
            }else if(oddEvenFlag == 0){
                //adding the even numbers in the given range.
                if( i % 2 == 0){

                    printf("%d",i);

                    if(i<topBorder-1){
                    printf(" + ");
                    }

                    result += i;
                }
            }else printf("Invalid Flag value.");

    }

            printf("= %lld", result);

            return result;

}

void write_file(int input){     //This function simply prints given input values to the results.txt file.

    FILE *fp;

    fp = fopen("results.txt","a+");

    fprintf(fp,"%d ",input);

    fclose(fp);


}

int prime_check_caller_function(int a){ // This function gives output to user according to the input it gets from isPrime function.

    if(isPrime(a) == 1){
        printf("%d is a prime number\n",a);
    }else{
        printf("%d is not a prime number, it is divisible by %d\n",a,isPrime(a));
    }
}

int isPrime(int a){ // Returns if a number is prime, if it is not prime, returns the smallest divisor of the number.

    int i=0;
    int counter = 0;

    for( i=2 ; i <= sqrt(a);i++){

        if(a % i == 0){
            counter++;
            return i; //Number is not prime, so we return the least divisor
        }
    }

    if(counter == 0){
        return 1; //Number is prime
    }
}

void print_file(){      // This function prints the values from result.txt onto the terminal screen.

FILE *fp;
fp = fopen("results.txt","r");
char carrierChar;

while(!feof(fp)){

    fscanf(fp,"%c",&carrierChar);
    printf("%c",carrierChar);
}

fclose(fp);

}

void sort_file(){

    long int min1 = 999999999;
    long int min2 = 999999999;    // to start the comparisons, these variables must start as always being bigger than the numbers which they are being compared with.
    long int min3 = 999999999;
    long int nextBorder = 0;  //in the next sorting operations, we will ignore numbers less than the numbers which had already sorted.
    int slave;                  // this variable is only used for counting the number of elements in the txt file.
    int carrier = 0;        //this variable is being used for writing the data from sorted.txt to results.txt .
    int forLoopBorder;
    int i=0;
    int printer;

    FILE *fp;
    fp = fopen("results.txt","r");
    int num = 0;
    int temp = 0; //for swapping values.

    FILE *fk; //we will write the 3 value we have sorted on a temporary txt file.
    fk = fopen("sorted.txt","a+");

    int counter=0; //to learn how many numbers are there in the results file.

    while(!feof(fp)){
        // This loop gives us the number of elements in the results.txt file.
        fscanf(fp,"%d ",&slave);
        counter++;
    }

    if(counter % 3 == 0){
        //Since we are sorting numbers 3 by 3, we need a for loop repeating the number of elements divided by 3 times.
        forLoopBorder = counter / 3;
    }else{
        forLoopBorder = (counter/3)+1;
    }


    for(i=0;i<forLoopBorder;i++){

    rewind(fp); //This moves the cursor at the beggining of the txt file.

    while(!feof(fp)){

        //This loop finds the least 3 numbers in a sequence of numbers.

        fscanf(fp,"%d ",&num);

        if( num > nextBorder){


        if(num < min3){
            min3 = num;
            //flag++;
            if(min3 < min2){

                temp = min2;
                min2 = min3;
                min3 = temp;
                //flag++;


                if(min2 < min1){

                    temp = min1;
                    min1 = min2;
                    min2 = temp;
                    //flag++;
                }
            }
        }

        }
    }

    nextBorder = min3;

    fprintf(fk,"%ld ",min1);
    fprintf(fk,"%ld ",min2);
    fprintf(fk,"%ld ",min3);

    //When we sort the numbers again, we need the min variables to always be bigger with the first 3 comparisons in order to let the sorting begin. So we set them to a huge value at the end of every sorting round.
    //This way they be ready for the next round of sorting.
    min1 = 999999999;
    min2 = 999999999;
    min3 = 999999999;

}
    fclose(fp);

    // In this part of the code, we are writing the sorted values from the sorted.txt to results.txt.

    fp = fopen("results.txt","w+");

    rewind(fp);
    rewind(fk);

    for(i=0;i<counter;i++){

        fscanf(fk,"%d ",&carrier);

        if(carrier < 999999999){
            // This control is only for when the number of elements are not divisible by 3, sorted.txt automatically fill the 1 or 2 empty places with 99999999.
            // But this is not designed for the user to see, so we do not carry them to our original results file.
            fprintf(fp,"%d ",carrier);
        }
    }

    fclose(fk);
    fclose(fp);

    fp = fopen("results.txt","r");

    printf("Sorting is completed:\nResult:\n");

    for(i=0;i<counter;i++){ //Prints the sorted values on terminal.

        fscanf(fp,"%d ",&printer);
        printf("%d ",printer);

    }


    }







